IFBandwidthPresets V. 1.00.00

This is an "experimental" plugin for SDR# that creates buttons to preset the IF filter Window, Bandwidth, and Order.
The number of buttons is dynamic.

To activate the plugin in SDR# just copy IFBandwidthPresets.dll and IFBandwdthPresets.xml in the "Plugin" folder.

To config the buttons edit the xml file and change the parameter accordingly to your needs.
The FilterType enumerator is:

        None = 0,
        Hamming = 1,
        Blackman = 2,
        BlackmanHarris4 = 3,
        BlackmanHarris7 = 4,
        HannPoisson = 5,
        Youssef = 6

Please consider at present time there is not sanity check or any verification about the config correctness.
If you get any errors, please check your IFBandwdthPresets.xml.

The plug-in is fully compatible with the newer SDR# versions using .NET 5.x framework.

This plugin is free to the SDR# users' community.
As such, I assume no responsibility for any problems the use of this plugin may cause.
You are invited for constructive comments and suggestions.

A huge thank you goes to Youssef for his unmatched friendliness and help.
 
73 de Max, N5NHJ (I8NHJ)
September 25, 2022

max.i8nhj@gmail.com